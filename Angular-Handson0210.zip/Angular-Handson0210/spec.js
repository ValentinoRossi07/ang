describe('Angular application Testing', function () {

    it('should login successfully', async function () {
        browser.get("http://localhost:61831/login");

        const username = element(by.css('input[name="username"]'));
        await username.sendKeys("admin");
        const password = element(by.css('input[name="password"]'));
        await password.sendKeys("password");

        const button = element(by.css('button[aria-label="login"]'))
        await button.click();

        const currentUrl = await browser.getCurrentUrl();
        expect(currentUrl.endsWith("/editEmployee")).toBe(true);
    });

    it('should Employees page have a search field', async function () {
        browser.get("http://localhost:61831/Employees");

        const searchInput = element(by.css('input[type="search"]'));

        expect(searchInput.isPresent()).toBe(true);

    });

    it('should Edit Employees Reactive page have a salary field', async function () {
        browser.get("http://localhost:61831/editEmployee");

        const salaryInput = element(by.css('input[name="salary"]'));

        expect(salaryInput.isPresent()).toBe(true);

    });

    it('should increment the value to 1', async function () {
        browser.get("http://localhost:61831/quantityIncrement");

        const Input = element(by.css('input[type="number"]'));
        const addButton = element(by.css('button[id="add"]'));

        await addButton.click()

        expect(Input.getAttribute('value')).toEqual("1");

    });

});