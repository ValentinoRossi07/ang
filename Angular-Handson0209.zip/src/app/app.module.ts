import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';

import {AppComponent} from './app.component';
import {EmployeeComponentComponent} from './employee-component/employee-component.component';
import {EmployeeComponent} from './employee/employee.component';
// import { EditEmpReactiveComponent } from './edit-emp-reactive/edit-emp-reactive.component';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {ViewEmployeeComponent} from './view-employee/view-employee.component';
import {EditEmployeeComponent} from './edit-employee/edit-employee.component';
import {MenuComponent} from './menu/menu.component';
import {AppRoutingModule} from "./app-routing.module";
import {QuantityIncreamentComponent} from './quantity-increament/quantity-increament.component';
import {EditEmployeeTemplateComponent} from './edit-employee-template/edit-employee-template.component';
import {EmployeeListComponent} from './employee-list/employee-list.component';
import {EmployeeInfoComponent} from './employee-list/employee-info/employee-info.component';
import {QuantitySelectorComponent} from './quantity-selector/quantity-selector.component';
import {EditEmployeeFormbuilderComponent} from './edit-employee-formbuilder/edit-employee-formbuilder.component';
import {LoginComponent} from './login/login.component';
import {UserComponent} from './user/user.component';
import {HttpClientModule} from "@angular/common/http";

@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponentComponent,
    EmployeeComponent,
    ViewEmployeeComponent,
    EditEmployeeComponent,
    MenuComponent,
    QuantityIncreamentComponent,
    EditEmployeeTemplateComponent,
    EmployeeListComponent,
    EmployeeInfoComponent,
    QuantitySelectorComponent,
    EditEmployeeFormbuilderComponent,
    LoginComponent,
    UserComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
}
