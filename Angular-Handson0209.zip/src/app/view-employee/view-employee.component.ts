import { Component, OnInit } from '@angular/core';
import {Employee} from "../model/Employee.model";

@Component({
  selector: 'app-view-employee',
  templateUrl: './view-employee.component.html',
  styleUrls: ['./view-employee.component.css']
})
export class ViewEmployeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  employees: Employee[] = [
    {
      id: 1,
      name: "Ram",
      salary: 20000,
      permanent: true,
      department: {
        id: 1,
        name: "cse"
      },
      skill: [
        {
          id: 1,
          name: 'C#'
        }
      ],
      dateOfBirth: new Date()
    }
  ]

}
