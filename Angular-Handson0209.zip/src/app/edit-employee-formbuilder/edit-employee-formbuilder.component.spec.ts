import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditEmployeeFormbuilderComponent } from './edit-employee-formbuilder.component';

describe('EditEmployeeFormbuilderComponent', () => {
  let component: EditEmployeeFormbuilderComponent;
  let fixture: ComponentFixture<EditEmployeeFormbuilderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditEmployeeFormbuilderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditEmployeeFormbuilderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
