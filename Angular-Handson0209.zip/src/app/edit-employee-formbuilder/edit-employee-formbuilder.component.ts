import {Component, OnInit} from '@angular/core';
import {Department} from "../model/Department.model";
import {Skill} from "../model/Skill.model";
import {Employee} from "../model/Employee.model";
import {FormArray, FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";

@Component({
  selector: 'app-edit-employee-formbuilder',
  templateUrl: './edit-employee-formbuilder.component.html',
  styleUrls: ['./edit-employee-formbuilder.component.css']
})
export class EditEmployeeFormbuilderComponent implements OnInit {

  department: Department[] = [];
  skill: Skill[] = [];

  employee: Employee =
    {
      id: 1,
      name: "Ramkumar",
      salary: 10000,
      permanent: false,
      department: {id: 1, name: "PayRoll"},
      skill: [
        {id: 1, name: "HTML"},
        {id: 2, name: "CSS"},
        {id: 3, name: "JavaScript"}],
      dateOfBirth: new Date("2000-06-15"),
    };

  editEmployee: FormGroup;

  constructor(public fb: FormBuilder) {
    this.editEmployee = this.fb.group({
      name: [this.employee.name, [Validators.required, Validators.minLength(4), Validators.maxLength(20)]],
      salary: [this.employee.salary, [Validators.required, Validators.min(5000), Validators.max(50000)]],
      permanent: [this.employee.permanent, [Validators.required]],
      department: [this.employee.department, [Validators.required]],
      employeeSkills: new FormArray([], [Validators.required])
    });
  }

  ngOnInit(): void {
    this.skill =
      [
        {id: 1, name: "React"},
        {id: 2, name: "Angular"},
        {id: 3, name: "Django"},
        {id: 4, name: "Machine Learning"},
        {id: 5, name: "Node JS"},
        {id: 6, name: "Graphics Design"},
        {id: 7, name: "DotNet"},
        {id: 8, name: "AWS"},
        {id: 9, name: "Azure"},
        {id: 10, name: "Data Analyst"}
      ];
    this.department =
      [
        {id: 1, name: "PayRoll"},
        {id: 2, name: "Internal"},
        {id: 3, name: "HR"}
      ];
  }

  onSubmit(data: any): void {
    console.log(data);
  }

  onCheckBoxChecked(data: any): void {
    const empSkill = <FormArray>this.editEmployee.get("employeeSkills");

    if (data.target.checked) {
      empSkill.push(new FormControl(data.target.value))
    } else {
      let i: number = 0;
      empSkill.controls.forEach(item => {
        if (item.value === data.target.value) {
          empSkill.removeAt(i);
          return;
        }
        i++;
      })
    }
  }

}
