import {Component, OnInit} from '@angular/core';
import {Router} from "@angular/router";
import {AuthService} from "../services/auth.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username: string = "";
  password: string = "";

  errorMessage: string = "";

  constructor(private router: Router, private auth: AuthService) {
  }

  ngOnInit(): void {
  }


  login(data: any): void {

    if (data.username === "admin" && data.password === "password") {
      this.errorMessage = "";
      this.auth.login();
      this.router.navigate(['editEmployee']);
    } else {
      this.errorMessage = "Invalid Username/Password";
    }
  }
}
