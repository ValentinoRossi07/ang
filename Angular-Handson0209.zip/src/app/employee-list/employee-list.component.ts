import { Component, OnInit } from '@angular/core';
import {Employee} from "../model/Employee.model";

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  employees: Employee[] = [
    {
      id: 1,
      name: "Ram",
      salary: 20000,
      permanent: true,
      department: {
        id: 1,
        name: "cse"
      },
      skill: [
        {
          id: 1,
          name: 'C#'
        }
      ],
      dateOfBirth: new Date()
    },
    {
      id: 2,
      name: "Mahi",
      salary: 20000,
      permanent: true,
      department: {
        id: 1,
        name: "cse"
      },
      skill: [
        {
          id: 1,
          name: 'C#'
        }
      ],
      dateOfBirth: new Date()
    },
    {
      id: 3,
      name: "Jayarath",
      salary: 1000,
      permanent: true,
      department: {
        id: 1,
        name: "cse"
      },
      skill: [
        {
          id: 1,
          name: 'C#'
        }
      ],
      dateOfBirth: new Date()
    }
  ];
  filterEmployee: Employee[] = this.employees;

  onSearch(data: any): void{
    this.filterEmployee = this.employees.filter((emp) => {
      return emp.name.toLowerCase().includes(data.target.value.toLowerCase());
    });
  }

}
