import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-quantity-selector',
  templateUrl: './quantity-selector.component.html',
  styleUrls: ['./quantity-selector.component.css']
})
export class QuantitySelectorComponent implements OnInit {


  constructor() {
  }

  ngOnInit(): void {
  }


  data = 0;

  addData() {
    this.data += 1;
  }

  subData() {
    this.data -= 1;
  }
}
