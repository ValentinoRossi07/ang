import {Component, OnInit} from '@angular/core';
import {UserService} from "../services/user.service";
import {User} from "../model/user.model";

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor(private user: UserService) {
  }

  users: User[] = [];
  dataLoaded: boolean = false

  newUser = {
    "email": "ramkumar.m@reqres.in",
    "first_name": "Ramkumar",
    "last_name": "M",
    "avatar": "https://reqres.in/img/faces/7-image.jpg"
  }

  ngOnInit(): void {
    this.user.getAllUsers().subscribe(users => {
      this.users = users.data;
      console.log(this.users);
      this.dataLoaded = true
    })

  }

  createUser(): void {

    this.user.createUser(this.newUser).subscribe(user => {
      delete user.createdAt;
      this.users.push(user);
    })
  }

  deleteUser(): void {
    this.user.deleteUser(this.users[1].id).subscribe(res => console.log(res))
  }

  updateUser(): void {
    this.user.updateUser(this.users[1]).subscribe(res => console.log(res))
  }


}
