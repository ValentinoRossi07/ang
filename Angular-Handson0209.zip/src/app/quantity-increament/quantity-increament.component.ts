import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-quantity-increament',
  templateUrl: './quantity-increament.component.html',
  styleUrls: ['./quantity-increament.component.css']
})
export class QuantityIncreamentComponent implements OnInit {

  constructor() {
  }

  ngOnInit(): void {
  }

  msg: string = "";
  value: number = 0;

  clickEvent(): any {
    this.msg = "Click me button clicked!";
    return this.msg;
  }

  increment(): void {
    this.value += 1;
  }

}
