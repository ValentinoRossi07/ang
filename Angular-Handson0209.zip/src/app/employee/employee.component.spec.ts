import {ComponentFixture, TestBed} from '@angular/core/testing';

import {EmployeeComponent} from './employee.component';
import {CurrencyPipe, DatePipe} from "@angular/common";

describe('EmployeeComponent', () => {
  let component: EmployeeComponent;
  let fixture: ComponentFixture<EmployeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EmployeeComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have a title "Employee Information"', function () {
    expect(component.title).toEqual("Employee Information");
  });

  it('should have an employee name "sam"', function () {
    expect(component.name).toEqual("sam");
  });

  it('should have an employee salary with value "9000"', function () {
    expect(component.salary.toString()).toEqual("90000");
  });

  it('should have an employee joining date with value "2021/05/20"', function () {
    expect(component.joiningDate).toEqual(new Date("2021/05/20"));
  });

  it('should render title in a h1 tag', function () {
    const app = fixture.nativeElement.querySelector('h1');
    expect(app.textContent).toBe(component.title);
  });

  it('should render employee name in h2 tag', function () {
    const app = fixture.nativeElement.querySelector('#name');
    expect(app.textContent).toBe(`Name: ${component.name}`);
    expect(app.tagName).toBe('H2');
  });

  it('should render employee salary in h2 tag', function () {
    const app = fixture.nativeElement.querySelector('#salary');
    const pipe = new CurrencyPipe("en-IN");
    const expected = pipe.transform(component.salary, "INR");

    expect(app.textContent).toBe(`Salary: ${expected}`);
    expect(app.tagName).toBe('H2');
  });

  it('should render employee joining date in h2 tag', function () {
    const app = fixture.nativeElement.querySelector('#joiningDate');
    const pipe = new DatePipe("en");
    const expected = pipe.transform(component.joiningDate, 'EEEE, MMMM d, y')

    expect(app.textContent).toBe(`Date Of Joining: ${expected}`);
    expect(app.tagName).toBe('H2');
  });

});
