import {Component, OnInit} from '@angular/core';
import {Employee} from "../model/Employee.model";
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {ActivatedRoute} from "@angular/router";
import {EmployeeService} from "../services/employee.service";
import {Department} from "../model/Department.model";


@Component({
  selector: 'app-edit-employee',
  templateUrl: './edit-employee.component.html',
  styleUrls: ['./edit-employee.component.css']
})
export class EditEmployeeComponent implements OnInit {
  empForm: FormGroup

  employees: any = {};

  departments: Department[] = [];


  constructor(private route: ActivatedRoute, private employeeService: EmployeeService) {


    const employeeId = this.route.snapshot.paramMap.get('id');
    console.log(`Employee ID ${employeeId} comes from Employee List Component through routing`);

    if (employeeId) {
      this.employees = this.employeeService.getEmployee(Number(employeeId));
    } else {
      this.employees = this.employeeService.getEmployee(1);
    }

    console.log(this.employees)

    this.empForm = new FormGroup({
      'name': new FormControl(this.employees.name, [
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(20)
      ]),
      'salary': new FormControl(this.employees.salary, [
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(20)
      ]),
      'permanent': new FormControl(this.employees.permanent, [
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(20)
      ]),
      'department': new FormControl(this.employees.department, [
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(20)
      ]),
    });

  }

  ngOnInit(): void {
    this.empForm.valueChanges.subscribe(value => {
      console.log(value);
    });
    this.departments = [

      {id: 1, name: "Payroll"},

      {id: 2, name: "Internal"},

      {id: 3, name: "HR"}
    ];
  }

  onSubmit(data: any) {
    console.warn(data);
  }
}
