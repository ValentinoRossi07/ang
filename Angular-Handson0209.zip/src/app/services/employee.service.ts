import {Injectable} from '@angular/core';
import {Employee} from "../model/Employee.model";

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  employees: Employee[] = [
    {
      id: 1,
      name: "Ram",
      salary: 20000,
      permanent: true,
      department: {
        id: 1,
        name: "Payroll"
      },
      skill: [
        {
          id: 1,
          name: 'C#'
        }
      ],
      dateOfBirth: new Date()
    },
    {
      id: 2,
      name: "Mahi",
      salary: 20000,
      permanent: true,
      department: {
        id: 1,
        name: "HR"
      },
      skill: [
        {
          id: 1,
          name: 'C#'
        }
      ],
      dateOfBirth: new Date()
    },
    {
      id: 3,
      name: "Jayarath",
      salary: 1000,
      permanent: true,
      department: {
        id: 1,
        name: "Internal"
      },
      skill: [
        {
          id: 1,
          name: 'C#'
        }
      ],
      dateOfBirth: new Date()
    }
  ];

  constructor() {
  }

  getAllEmployees(): Employee[] {
    return this.employees;
  }

  filteredEmployee: any = {}

  getEmployee(employeeId: number): Employee {
    this.filteredEmployee = this.employees.filter(x => x.id === employeeId)
    console.log(this.filteredEmployee)
    return this.filteredEmployee[0];
  }
}
