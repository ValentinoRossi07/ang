import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditEmployeeTemplateComponent } from './edit-employee-template.component';

describe('EditEmployeeTemplateComponent', () => {
  let component: EditEmployeeTemplateComponent;
  let fixture: ComponentFixture<EditEmployeeTemplateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditEmployeeTemplateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditEmployeeTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
