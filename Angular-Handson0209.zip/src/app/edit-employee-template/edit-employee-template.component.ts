import { Component, OnInit } from '@angular/core';
import {Employee} from "../model/Employee.model";
import {Department} from "../model/Department.model";

@Component({
  selector: 'app-edit-employee-template',
  templateUrl: './edit-employee-template.component.html',
  styleUrls: ['./edit-employee-template.component.css']
})
export class EditEmployeeTemplateComponent implements OnInit {

  constructor() { }

  departments: Department[] = [];
  ngOnInit(): void {
    this.departments=[{id:1,name:"Payroll"},{id:2,name:"Internal"},{id:3,name:"HR"}];
  }


  employees: Employee =
    {
      id: 1,
      name: "Ramkumar",
      salary: 50000,
      permanent: true,
      department: {id:1,name:"PayRoll"},
      skill: [
        {
          id: 1,
          name: 'C#'
        }
      ],
      dateOfBirth: new Date()
    };

    onSubmit(data: any){
      console.log(data);
    }
}
